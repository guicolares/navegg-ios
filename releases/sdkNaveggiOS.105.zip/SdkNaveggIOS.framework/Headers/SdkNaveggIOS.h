//
//  SdkNaveggIOS.h
//  SdkNaveggIOS
//
//  Created by Navegg on 11/01/18.
//  Copyright © 2018 Navegg. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SdkNaveggIOS.
FOUNDATION_EXPORT double SdkNaveggIOSVersionNumber;

//! Project version string for SdkNaveggIOS.
FOUNDATION_EXPORT const unsigned char SdkNaveggIOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SdkNaveggIOS/PublicHeader.h>


